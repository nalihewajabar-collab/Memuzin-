const fs=require('fs'),path=require('path'),bcrypt=require('bcryptjs');
(async()=>{const p=path.join(__dirname,'data/database.json');const d=JSON.parse(fs.readFileSync(p));for(const u of d.users)u.passwordHash=await bcrypt.hash('Demo@12345',12);fs.writeFileSync(p,JSON.stringify(d,null,2));console.log('Demo password: Demo@12345')})();
